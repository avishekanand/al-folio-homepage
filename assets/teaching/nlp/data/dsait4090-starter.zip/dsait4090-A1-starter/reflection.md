# A1 reflection

Max 200 words in total for the three questions (the AI-use declaration does not count).
Keep the headings exactly as they are.

## 1. What did you know before?


## 2. What was hardest, and how did you get unstuck?


## 3. Read your samples.txt. Whose continuations read better, your n-gram's or TULIP's? Does that agree with their per-byte perplexities? What does this tell you about what perplexity measures, and what would you try next?


## AI-use declaration

