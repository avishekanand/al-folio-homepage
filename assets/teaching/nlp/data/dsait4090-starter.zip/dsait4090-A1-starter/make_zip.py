"""Build A1_<studentnumber>.zip and run the format checker on it.

    python make_zip.py 1234567

The zip contains: submission/ (a1_results.json, tokenizer.json, sweep/, samples.txt) at the top level,
findings.md, reflection.md, and code/ with a1.py plus any extra .py files of your own in this folder.
It never contains your .env (TULIP key), the TULIP cache, the usage log, the data or compiled files.
"""
import os, re, subprocess, sys, zipfile

KIT = os.path.dirname(os.path.abspath(__file__))
KIT_FILES = {"load_data.py", "tulip_client.py", "tulip_check.py", "selftest.py", "make_zip.py", "check_submission.py"}
SUBMISSION_FILES = re.compile(r"^(a1_results\.json|tokenizer\.json|samples\.txt|sweep/tokenizer_\d+\.json)$")


def main():
    if len(sys.argv) != 2 or not sys.argv[1].strip().isdigit():
        print("usage: python make_zip.py <studentnumber>    (digits only, the same number you gave a1.py)")
        return 2
    sn = sys.argv[1].strip()
    sub = os.path.join(KIT, "submission")
    if not os.path.exists(os.path.join(sub, "a1_results.json")):
        print(f"✗ submission/a1_results.json not found. Run `python a1.py --student-number {sn}` first.")
        return 1
    out = os.path.join(KIT, f"A1_{sn}.zip")
    added = []
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for dp, _, fs in os.walk(sub):
            for f in sorted(fs):
                rel = os.path.relpath(os.path.join(dp, f), sub).replace(os.sep, "/")
                if SUBMISSION_FILES.match(rel):
                    z.write(os.path.join(dp, f), rel); added.append(rel)
        for f in ("findings.md", "reflection.md", "reflection.pdf"):
            if os.path.exists(os.path.join(KIT, f)):
                z.write(os.path.join(KIT, f), f); added.append(f)
        for f in sorted(os.listdir(KIT)):
            if f.endswith(".py") and f not in KIT_FILES and os.path.isfile(os.path.join(KIT, f)):
                z.write(os.path.join(KIT, f), "code/" + f); added.append("code/" + f)
    print(f"wrote {out} ({len(added)} files: {', '.join(added)})\nrunning the checker:\n", flush=True)
    rc = subprocess.call([sys.executable, os.path.join(KIT, "check_submission.py"), out])
    if rc == 0:
        print(f"\nUpload this file: {out}")
    else:
        print("\nFix the ✗ errors above, then run make_zip.py again.")
    return rc


if __name__ == "__main__":
    sys.exit(main())
