# DSAIT4090 — assignment starter

1. **Install:** `python -m pip install -r requirements.txt` (Python 3.12 recommended).
2. **Get the data from Kaggle** (it is the public competition, not a course upload):
   - Create a free Kaggle account and **join** *Jigsaw Unintended Bias in Toxicity Classification*.
   - Set up API credentials: put `kaggle.json` in `~/.kaggle/`, **or** `pip install kagglehub` and log in.
   - Then `load_data.py` fetches and derives the splits for you:
     ```python
     from load_data import load_textclf, load_lm, load_canaries, load_predictions
     data = load_textclf()          # train / validation / test (binary toxicity + identity subgroups)
     train, heldout = load_lm()     # raw comment text for LM work
     ```
   - Models come from **HuggingFace** as usual (`transformers`). Register a free HF account for your own
     model/dataset namespace if you want to push anything — no organisation needed.
3. **Before submitting:** `python check_submission.py A3 <your-zip-or-dir>` — validates file names,
   schemas and value ranges. A passing check is a precondition for auto-grading.

Helpers in `load_data.py`: `load_textclf()`, `load_lm()`, `load_canaries()`, `load_predictions()`.
Sampling is deterministic (`SEED`), so your splits match the grader's. *Content note: comments can be offensive.*
