# A1 data: `a1_data.json.gz`

A small, fixed sample of **WikiText-103** shipped with the kit, so you download nothing.
Do not edit it: your held-out set and the grader's are drawn from this exact file.

## Source and licence

- WikiText-103 (Stephen Merity, Caiming Xiong, James Bradbury, Richard Socher, 2016, *Pointer Sentinel
  Mixture Models*), built from Wikipedia articles.
- HuggingFace dataset `Salesforce/wikitext`, configuration `wikitext-103-raw-v1`,
  revision `b08601e04326c79dfdd32d625aee71d232d685c3`.
- Licence: **Creative Commons Attribution-ShareAlike 3.0 (CC BY-SA 3.0)**. This derived sample is
  distributed under the same licence.

## Contents (gzip-compressed UTF-8 JSON)

| key | what |
|---|---|
| `train` | 5000 paragraphs from the WikiText-103 **train** split (the same for everyone) |
| `pool` | 500 paragraphs from the WikiText-103 **test** split; `load_lm()` draws your 300 held-out paragraphs from it |
| `prompts` | the 5 generation prompts (from the **validation** split) |
| `version`, `source`, `derivation` | provenance |

## Exact derivation

- **Paragraph:** one raw WikiText line, `.strip()`-ed, that is not a heading (does not start with `=`,
  e.g. ` = Title = ` or ` = = Section = = `), with 150 to 1200 characters (inclusive) after stripping.
  Identical paragraphs are kept once.
- The text is kept exactly as in the raw configuration, including WikiText's artefacts: ` @-@ `, ` @,@ ` and
  ` @.@ ` around hyphens and number separators, and spaces before punctuation (`city 's`, `word .`).
  Both models see exactly this text.
- `train` = `random.Random(4090).sample(eligible train paragraphs, 5000)`.
- `pool` = `random.Random(4091).sample(eligible test paragraphs, 500)`.
- `prompts` = the first 8 words of `random.Random(4092).sample(eligible validation paragraphs without '@'
  that start with an upper-case letter, 5)`.
- Your held-out set: `load_data.lm_heldout_indices(student_number)` = sorted
  `random.Random(f"4090:{int(student_number)}").sample(range(500), 300)`.

Statistics: train 5000 paragraphs (150-1200 characters, mean 642, 3.22 MB UTF-8); pool 500 paragraphs
(mean 633 characters, 0.32 MB); a held-out set of 300 paragraphs is about 190,000 bytes.
