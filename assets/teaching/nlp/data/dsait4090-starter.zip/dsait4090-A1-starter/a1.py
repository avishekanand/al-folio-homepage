"""DSAIT4090 A1: byte-level BPE + n-gram LM vs TULIP, per-token vs per-byte perplexity, and samples.

YOU WRITE the four parts marked `TODO (you)`:
    NGramLM.fit       counting                                   (task 2)
    NGramLM.prob      add-k smoothing                            (task 2)
    doc_nll           one paragraph's NLL from TULIP log-probs   (task 3)
    NGramLM.sample    one continuation from your model           (task 5)
Everything else is PROVIDED: tokenizer training, choosing k on dev, the vocab sweep (257 / 1000 / 8000),
TULIP scoring and generation (through tulip_client.py), perplexities, samples.txt and submission/.

    python selftest.py                                  # check your TODOs offline (fake TULIP)
    python a1.py --student-number 1234567               # the real run (TULIP needed)
    python a1.py --student-number 1234567 --mock        # same pipeline, fake TULIP, no network
    python make_zip.py 1234567                          # build A1_1234567.zip and check it

Optional variants (no extra points, never penalised): --order 3 (trigram) and --smoothing interpolated_kn
(Kneser-Ney: you would add it to fit/prob yourself; selftest.py has optional tests for it).
"""
import argparse, hashlib, json, math, os, random, sys, time
from collections import Counter, defaultdict

KIT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, KIT)

BOS = -1               # the <s> padding symbol of the n-gram: context only, never predicted
MAIN_VOCAB = 8000
SWEEP = (257, 1000, 8000)
K_GRID = (1.0, 0.1, 0.01, 0.001)
KN_GRID = (0.5, 0.75, 0.9)
N_PROMPTS, MAX_NEW_TOKENS, TEMPERATURE = 5, 40, 1.0
N_SURPRISING = 10      # how many "most surprising tokens" to list per model


# ============================ Task 1: tokenizer (PROVIDED) ============================
def train_tokenizer(train_docs, vocab_size):
    """Byte-level BPE (HuggingFace `tokenizers`). Byte-level means lossless: every string is encoded, no
    [UNK], whitespace kept, so decode(encode(x)) == x. The 256 byte symbols plus one special token give
    vocab_size 257 = pure bytes (no merges)."""
    from tokenizers import Tokenizer, models, trainers, pre_tokenizers, decoders
    tok = Tokenizer(models.BPE())
    tok.pre_tokenizer = pre_tokenizers.ByteLevel(add_prefix_space=False)
    tok.decoder = decoders.ByteLevel()
    trainer = trainers.BpeTrainer(vocab_size=vocab_size, special_tokens=["<s>"],
                                  initial_alphabet=pre_tokenizers.ByteLevel.alphabet(), show_progress=False)
    tok.train_from_iterator(train_docs, trainer=trainer)
    return tok


def encode(tok, docs):
    """Token ids per paragraph: tok.encode(p).ids (no special tokens are added)."""
    return [e.ids for e in tok.encode_batch(list(docs), add_special_tokens=False)]


# ============================ Task 2 + 5: your n-gram LM ============================
class NGramLM:
    """Order-n language model over token ids (order 2 = bigram, the default; 3 = trigram).

    Definitions (the grader recomputes your numbers with exactly these):
      * each paragraph is scored on its own. It is padded on the LEFT with order-1 BOS symbols (<s>):
        context only, never predicted. Every paragraph token is predicted; there is no end token.
      * an event is (h, w): w is a paragraph token, h the tuple of the order-1 symbols before it
        (h may contain BOS). self.histories(doc) yields exactly these events.
      * V = self.V, the tokenizer's vocabulary size.
      * add-k:  P(w | h) = (c(h, w) + k) / (c(h) + k * V),   where c(h) = sum over all w' of c(h, w').
        A history never seen in training has c(h) = 0, so P(w | h) = 1/V for every w.
      * interpolated_kn (OPTIONAL, no extra points): only if you choose to implement it.
    """

    def __init__(self, order=2, smoothing="add_k", vocab_size=None, k=0.01, discount=0.75):
        assert order in (2, 3), "order must be 2 or 3"
        assert smoothing in ("add_k", "interpolated_kn")
        self.order, self.smoothing, self.V, self.k, self.d = order, smoothing, vocab_size, k, discount

    def histories(self, doc):
        """Yields (history_tuple, w) for every token w of one paragraph (provided)."""
        n = self.order
        padded = [BOS] * (n - 1) + list(doc)
        for i in range(n - 1, len(padded)):
            yield tuple(padded[i - n + 1:i]), padded[i]

    def fit(self, docs):
        """docs: a list of paragraphs, each a list of token ids. Count c(h, w) for every event (h, w) of
        every paragraph (see self.histories) and c(h) for every history, so that prob() can use them.
        Must return self."""
        # TODO (you): counting. A dict of dicts (or a Counter) keyed by the history tuple works well.
        #   (Only if you choose interpolated_kn: also build what Kneser-Ney needs.)
        raise NotImplementedError("TODO: NGramLM.fit")
        return self

    def prob(self, history, w):
        """P(w | history) with add-k smoothing as defined in the class docstring (k = self.k, V = self.V).
        history is a tuple of length order-1. A history never seen in training gives 1/V.
        Summed over all w in range(V), the result is 1 for every history."""
        # TODO (you): the add-k formula. (interpolated_kn is optional: raise NotImplementedError for it if
        #   you do not do it.)
        raise NotImplementedError("TODO: NGramLM.prob")

    def sample(self, prompt_ids, max_tokens=MAX_NEW_TOKENS, seed=0):
        """Sample one continuation of a prompt from this model's distribution, at temperature 1.0.

        prompt_ids: the prompt's token ids (tok.encode(prompt).ids). The history of the first new token
        is the last order-1 symbols of [BOS]*(order-1) + prompt_ids, exactly as in histories().
        Repeat max_tokens times: draw the next token w from P(w | h) over ALL w in range(V) (temperature
        1.0 = the distribution itself: no top-k, no greedy argmax), append it, and move the history on.
        There is no end token, so the result has exactly max_tokens ids.
        Use rng = random.Random(seed) as the only source of randomness, so the same seed gives the same
        sample. Returns the list of NEW token ids (without the prompt)."""
        # TODO (you): one draw per step. random.Random has a method that draws an item with given weights.
        raise NotImplementedError("TODO: NGramLM.sample")

    def nll(self, doc):
        """Total negative log-likelihood (nats) of one paragraph's token ids (provided)."""
        return -sum(math.log(self.prob(h, w)) for h, w in self.histories(doc))


# ============================ Task 3: scoring one paragraph with TULIP ============================
def doc_nll(token_logprobs):
    """The negative log-likelihood (nats) of ONE paragraph under TULIP, from the client's output.

    token_logprobs: what TulipClient.score() returns for one paragraph: a list of (token, logprob) pairs,
    one per paragraph token, in order (token is TULIP's token id as a string: TULIP sends no token text,
    and you do not need it). The logprobs are natural logs (<= 0). Per the protocol every
    paragraph token was scored with the start-of-text token as context and the client has already removed
    the start-of-text token itself: every entry is a paragraph token and counts, including the first.
    There is no end token.
    Return NLL = minus the sum of the log-probs, as a float (>= 0).
    If any logprob is None, that token was not scored: raise a ValueError instead of skipping it.
    """
    # TODO (you): a few lines.
    raise NotImplementedError("TODO: doc_nll")


# ============================ everything below is PROVIDED ============================
def ppl(nll, n):
    return math.exp(nll / n)


def corpus_nll(model, docs):
    """(total NLL in nats, number of predicted tokens) over a list of token-id paragraphs."""
    return sum(model.nll(d) for d in docs), sum(len(d) for d in docs)


def unseen_bigram_rate(ids_train, ids_held):
    """Fraction of held-out (previous token, token) pairs never seen in training (BOS-padded bigrams)."""
    seen = set()
    for d in ids_train:
        seen.update(zip([BOS] + d[:-1], d))
    pairs = [p for d in ids_held for p in zip([BOS] + d[:-1], d)]
    return sum(p not in seen for p in pairs) / max(1, len(pairs))


def run_vocab(train, fit, dev, held, V_target, order, smoothing, grid, log):
    t0 = time.time()
    tok = train_tokenizer(train, V_target)
    V = tok.get_vocab_size()
    ids_fit, ids_dev, ids_train, ids_held = encode(tok, fit), encode(tok, dev), encode(tok, train), encode(tok, held)
    param = "k" if smoothing == "add_k" else "discount"
    dev_results = {}
    for g in grid:                                 # choose k (or the discount) on dev: fit on 4500, score 500
        m = NGramLM(order, smoothing, V, **{param: g}).fit(ids_fit)
        nll, n = corpus_nll(m, ids_dev)
        dev_results[repr(g)] = ppl(nll, n)
    best = min(grid, key=lambda g: dev_results[repr(g)])
    model = NGramLM(order, smoothing, V, **{param: best}).fit(ids_train)   # refit on all 5000 paragraphs
    nll, n = corpus_nll(model, ids_held)
    nbytes = sum(len(x.encode("utf-8")) for x in held)
    rec = {"vocab_size": V, param: best, "dev_results": dev_results, "n_tokens": n, "nll": nll,
           "ppl_token": ppl(nll, n), "ppl_byte": ppl(nll, nbytes), "bytes_per_token": nbytes / n,
           "avg_tokens_per_doc": n / len(held), "unseen_bigram_rate": unseen_bigram_rate(ids_train, ids_held)}
    log(f"  vocab {V:>5}: {param}={best:<6} dev ppl/token={dev_results[repr(best)]:9.2f} | held-out "
        f"ppl/token={rec['ppl_token']:9.2f} ppl/byte={rec['ppl_byte']:.4f} tokens={n} ({time.time() - t0:.0f}s)")
    return tok, model, rec


def top_distinct(items, key_of, n=N_SURPRISING):
    """items: (nll, paragraph, position). The n highest-NLL items with distinct tokens (ties: earliest first)."""
    out, seen = [], set()
    for nll, d, i in sorted(items, key=lambda x: (-x[0], x[1], x[2])):
        k = key_of(d, i)
        if k not in seen:
            seen.add(k)
            out.append((nll, d, i))
            if len(out) == n:
                break
    return out


def ngram_surprising(model, tok, held, n=N_SURPRISING):
    """The n distinct held-out tokens with the highest NLL (-ln P) under the n-gram, decoded with its own
    tokenizer, each with a bit of context."""
    enc = [tok.encode(p).ids for p in held]
    items = [(-math.log(model.prob(h, w)), d, i) for d, ids in enumerate(enc) for i, (h, w) in enumerate(model.histories(ids))]
    return [{"token": tok.decode([enc[d][i]]), "context": tok.decode(enc[d][max(0, i - 6):i])[-30:],
             "nll": round(nll, 3), "paragraph": d, "position": i}
            for nll, d, i in top_distinct(items, lambda d, i: enc[d][i], n)]


def tulip_surprising(scored, held, mock, n=N_SURPRISING):
    """(list, note): the n distinct held-out tokens with the highest NLL under TULIP. TULIP returns token ids
    only, so they are decoded with Gemma 4's tokenizer (downloaded once); in mock mode with the mock tokenizer."""
    import tulip_client as tc
    items = [(-lp, d, i) for d, s in enumerate(scored) for i, (_, lp) in enumerate(s)]
    top = top_distinct(items, lambda d, i: scored[d][i][0], n)
    if mock:
        dec, note = (lambda d, a, b: "".join(tc.mock_tokenize(held[d])[a:b])), "mock tokens (fake TULIP)"
    else:
        gt, note = tc.tulip_tokenizer()
        dec = (lambda d, a, b: gt.decode([int(t) for t, _ in scored[d][a:b]])) if gt else None
    out = []
    for nll, d, i in top:
        tid = scored[d][i][0]
        out.append({"token": dec(d, i, i + 1) if dec else f"<id {tid}>", "token_id": str(tid),
                    "context": dec(d, max(0, i - 6), i)[-30:] if dec else "", "nll": round(nll, 3),
                    "paragraph": d, "position": i})
    return out, note


def sample_seed(student_number, i):
    return int(hashlib.sha256(f"A1:{int(student_number)}:{i}".encode()).hexdigest()[:8], 16)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--student-number", required=True, help="digits only, as in A1_<studentnumber>.zip")
    ap.add_argument("--order", type=int, default=2, choices=[2, 3], help="optional: 3 = trigram")
    ap.add_argument("--smoothing", default="add_k", choices=["add_k", "interpolated_kn"],
                    help="optional: interpolated_kn if you implemented Kneser-Ney")
    ap.add_argument("--mock", action="store_true", help="fake TULIP, no network (same as TULIP_MOCK=1)")
    ap.add_argument("--out", default=os.path.join(KIT, "submission"))
    a = ap.parse_args()
    sn = a.student_number.strip()
    if not sn.isdigit():
        ap.error("--student-number must be digits only (the number in A1_<studentnumber>.zip)")
    from load_data import load_lm, lm_dev_split, load_prompts
    from tulip_client import TulipClient, TulipError, KIT_VERSION
    log = lambda s="": print(s, flush=True)
    t_start = time.time()

    client = TulipClient(student_number=sn, mock=True if a.mock else None)
    grid = K_GRID if a.smoothing == "add_k" else KN_GRID
    param = "k" if a.smoothing == "add_k" else "discount"
    os.makedirs(os.path.join(a.out, "sweep"), exist_ok=True)

    train, held = load_lm(sn)
    fit, dev = lm_dev_split(train)
    prompts = load_prompts()
    nbytes = sum(len(x.encode("utf-8")) for x in held)
    log(f"student {sn}: train {len(train)} paragraphs (fit {len(fit)} + dev {len(dev)}), "
        f"held-out {len(held)} paragraphs = {nbytes} bytes; TULIP mode: {client.mode}")
    if client.mock:
        log("  ! MOCK mode: TULIP numbers and samples are fake. Fine for testing, not for your submission.")

    # ---- tasks 1, 2, 4: tokenizer + n-gram + perplexities, for every vocab size of the sweep
    log(f"n-gram: order {a.order}, {a.smoothing}, choosing {param} from {list(grid)} on dev")
    recs, main_tok, main_model = {}, None, None
    for V_target in SWEEP:
        tok, model, rec = run_vocab(train, fit, dev, held, V_target, a.order, a.smoothing, grid, log)
        fname = "tokenizer.json" if V_target == MAIN_VOCAB else f"sweep/tokenizer_{V_target}.json"
        tok.save(os.path.join(a.out, fname))
        rec["tokenizer_file"] = fname
        recs[V_target] = rec
        if V_target == MAIN_VOCAB:
            main_tok, main_model = tok, model
    main_rec = recs[MAIN_VOCAB]

    # ---- task 3: TULIP scoring of the 300 held-out paragraphs
    log(f"TULIP: scoring {len(held)} paragraphs with model '{client.model}' (cached after the first run) ...")
    try:
        scored = client.score(held)
    except TulipError as e:
        log(f"\n✗ TULIP: {e}\n  The n-gram numbers above are fine; a1_results.json is written once TULIP scoring works.")
        return 1
    t_nll = sum(doc_nll(s) for s in scored)
    t_n = sum(len(s) for s in scored)
    surprising = {"ngram": ngram_surprising(main_model, main_tok, held)}
    surprising["tulip"], tulip_note = tulip_surprising(scored, held, client.mock)
    surprising["tulip_note"] = tulip_note

    # ---- task 5: samples
    log(f"samples: {N_PROMPTS} prompts, at most {MAX_NEW_TOKENS} new tokens, temperature {TEMPERATURE}")
    seeds = [sample_seed(sn, i) for i in range(len(prompts))]
    ngram_cont = []
    for p, s in zip(prompts, seeds):
        p_ids = main_tok.encode(p).ids
        new = main_model.sample(p_ids, max_tokens=MAX_NEW_TOKENS, seed=s)
        ngram_cont.append(main_tok.decode(list(p_ids) + list(new))[len(p):])    # lossless: decode(p_ids) == p
    try:
        tulip_cont = client.generate(prompts, max_tokens=MAX_NEW_TOKENS, temperature=TEMPERATURE)
    except TulipError as e:
        log(f"\n✗ TULIP generation: {e}")
        return 1
    order_name = {2: "bigram", 3: "trigram"}[a.order]
    with open(os.path.join(a.out, "samples.txt"), "w", encoding="utf-8") as fh:
        fh.write(f"# A1 samples, student {sn}. n-gram: {order_name}, {a.smoothing} ({param}={main_rec[param]}), "
                 f"vocab {main_rec['vocab_size']}. TULIP: model '{client.model}' ({client.mode}). "
                 f"At most {MAX_NEW_TOKENS} new tokens, temperature {TEMPERATURE}.\n")
        for i, (p, g, t) in enumerate(zip(prompts, ngram_cont, tulip_cont), 1):
            sep = "" if not t or t[0].isspace() or t[0] in ",.;:!?)'" else " "   # the chat answer has no leading space
            fh.write(f"\n=== Prompt {i}: {p}\n[n-gram] {p}{g}\n[TULIP]  {p}{sep}{t}\n")

    # ---- a1_results.json
    out = {
        "ngram_ppl_token": main_rec["ppl_token"], "ngram_ppl_byte": main_rec["ppl_byte"],
        "tulip_ppl_token": ppl(t_nll, t_n), "tulip_ppl_byte": ppl(t_nll, nbytes),
        "meta": {
            "student_number": sn, "n_heldout_docs": len(held), "n_bytes": nbytes,
            "tokenizer_file": "tokenizer.json", "vocab_size": main_rec["vocab_size"],
            "avg_tokens_per_doc": main_rec["avg_tokens_per_doc"],
            "order": a.order, "smoothing": a.smoothing,
            "k": main_rec.get("k"), "discount": main_rec.get("discount"), "grid": list(grid),
            "dev_results": main_rec["dev_results"],
            "ngram_n_tokens": main_rec["n_tokens"], "ngram_total_nll": main_rec["nll"],
            "tulip_n_tokens": t_n, "tulip_total_nll": t_nll, "tulip_model": client.model,
            "tulip_mode": client.mode, "kit_version": KIT_VERSION, "surprising_tokens": surprising,
            "sweep": [{k: r.get(k) for k in ("vocab_size", "tokenizer_file", param, "dev_results", "n_tokens",
                                             "ppl_token", "ppl_byte", "bytes_per_token", "unseen_bigram_rate")}
                      for _, r in sorted(recs.items())],
        },
        "samples": {"file": "samples.txt", "n_prompts": len(prompts), "max_tokens": MAX_NEW_TOKENS,
                    "temperature": TEMPERATURE, "ngram_seeds": seeds, "tulip_model": client.model},
    }
    path = os.path.join(a.out, "a1_results.json")
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(out, fh, indent=2)

    # ---- summary: every number the findings questions need
    log(f"\nwrote {path}, {os.path.join(a.out, 'samples.txt')}, tokenizer.json, sweep/")
    log(f"\n{'model':<18}{'vocab':>7}{'N_tokens':>10}{'N_bytes':>9}{'bytes/tok':>10}{'PPL/token':>11}{'PPL/byte':>10}"
        f"{param:>10}{'unseen bigrams':>16}")
    for _, r in sorted(recs.items()):
        log(f"{'n-gram ' + order_name:<18}{r['vocab_size']:>7}{r['n_tokens']:>10}{nbytes:>9}{r['bytes_per_token']:>10.3f}"
            f"{r['ppl_token']:>11.2f}{r['ppl_byte']:>10.4f}{r[param]:>10}{r['unseen_bigram_rate']:>15.1%}")
    log(f"{'TULIP ' + client.model + (' (MOCK)' if client.mock else ''):<18}{'-':>7}{t_n:>10}{nbytes:>9}{nbytes / t_n:>10.3f}"
        f"{ppl(t_nll, t_n):>11.2f}{ppl(t_nll, nbytes):>10.4f}")
    log("dev PPL/token per " + param + ": " + "; ".join(
        f"V={r['vocab_size']}: " + ", ".join(f"{g}: {v:.1f}" for g, v in r["dev_results"].items()) for _, r in sorted(recs.items())))
    log(f"TULIP tokens used this run: {client.tokens_used:,} (cache hits are free). Total time {time.time() - t_start:.0f}s.")
    for name, key in ((f"your {main_rec['vocab_size']} n-gram", "ngram"), (f"TULIP ({tulip_note})", "tulip")):
        log(f"\nThe {N_SURPRISING} most surprising held-out tokens (distinct) for {name}: NLL = -ln P, context -> token")
        for e in surprising[key]:
            log(f"  {e['nll']:7.2f}  {e['context']!r:>34} -> {e['token']!r}   (paragraph {e['paragraph']}, token {e['position']})")
    if client.mock:
        log("! These TULIP numbers are FAKE (mock mode). Re-run without --mock / TULIP_MOCK before you submit.")
    log(f"\nNext: read samples.txt, answer findings.md and reflection.md, then `python make_zip.py {sn}`.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
