"""DSAIT4090 data loader — Kaggle (Jigsaw Unintended Bias) -> assignment-ready splits.

The data is the public Kaggle competition
    jigsaw-unintended-bias-in-toxicity-classification
(NOT a course-hosted upload). You must JOIN the competition on Kaggle and have API
credentials (`~/.kaggle/kaggle.json`, or `pip install kagglehub` + browser login).

    from load_data import load_textclf, load_lm, load_canaries, load_predictions
    data = load_textclf()          # {"train":[...], "validation":[...], "test":[...]}
    train, heldout = load_lm()     # two lists of comment strings
    canaries = load_canaries()     # [{"canary":..., "frequency":int}, ...]
    preds = load_predictions()     # {"A":[...], "B":[...], "C":[...]} over validation

Each classification row: {id, text, label in {toxic,nontoxic}, subgroup}. The `test` split has no
label (hidden grading reference). Everything is sampled deterministically (SEED) so splits are stable.
Content note: comments can be offensive.
"""
import os, csv, hashlib, random

SLUG = "jigsaw-unintended-bias-in-toxicity-classification"
IDENTITIES = ["male", "female", "homosexual_gay_or_lesbian", "christian", "jewish",
              "muslim", "black", "white", "psychiatric_or_mental_illness"]
SEED = 7
N_CLF = int(os.environ.get("DSAIT_N_CLF", "12000"))   # sampled classification rows
N_LM = int(os.environ.get("DSAIT_N_LM", "5000"))      # sampled LM documents
SPLIT = (0.70, 0.15, 0.15)                             # train / validation / test


# ---------- obtaining train.csv (Kaggle) ----------
def _train_csv_path():
    p = os.environ.get("DSAIT_JIGSAW_TRAIN")           # explicit override (also used by tests)
    if p and os.path.exists(p):
        return p
    # 1) kaggle API: download just train.csv
    try:
        import kaggle  # noqa
        from kaggle.api.kaggle_api_extended import KaggleApi
        api = KaggleApi(); api.authenticate()
        dest = os.path.expanduser("~/.cache/dsait4090")
        os.makedirs(dest, exist_ok=True)
        tp = os.path.join(dest, "train.csv")
        if not os.path.exists(tp):
            api.competition_download_file(SLUG, "train.csv", path=dest)
            zp = tp + ".zip"
            if os.path.exists(zp):
                import zipfile; zipfile.ZipFile(zp).extractall(dest); os.remove(zp)
        return tp
    except Exception as e:
        print(f"[load_data] kaggle API unavailable ({e}); trying kagglehub…")
    # 2) kagglehub: downloads the competition files, returns a dir
    import kagglehub
    d = kagglehub.competition_download(SLUG)
    for root, _, files in os.walk(d):
        if "train.csv" in files:
            return os.path.join(root, "train.csv")
    raise FileNotFoundError("train.csv not found in the Kaggle download")


def _load_train_df():
    import pandas as pd
    cols = {"id", "comment_text", "target", *IDENTITIES}
    df = pd.read_csv(_train_csv_path(), usecols=lambda c: c in cols)
    return df


# ---------- pure derivation (testable without Kaggle) ----------
def _derive_clf(df):
    """df -> {"train":[...], "validation":[...], "test":[...]} + hidden gold for test."""
    import numpy as np
    d = df.dropna(subset=["comment_text"]).copy()
    d["label"] = np.where(d["target"].fillna(0.0) >= 0.5, "toxic", "nontoxic")
    ident = d[[c for c in IDENTITIES if c in d.columns]].fillna(0.0)
    maxid = ident.max(axis=1)
    primary = ident.idxmax(axis=1)
    d["subgroup"] = np.where(maxid >= 0.5, primary, "none")
    d = d.rename(columns={"comment_text": "text"})[["id", "text", "label", "subgroup"]]
    d = d.sample(n=min(len(d), N_CLF), random_state=SEED).reset_index(drop=True)
    n = len(d); a = int(n * SPLIT[0]); b = a + int(n * SPLIT[1])
    rows = d.to_dict("records")
    train, val, test = rows[:a], rows[a:b], rows[b:]
    gold = [{"id": r["id"], "label": r["label"], "subgroup": r["subgroup"]} for r in test]
    test_inputs = [{"id": r["id"], "text": r["text"]} for r in test]
    return {"train": train, "validation": val, "test": test_inputs}, gold


def load_textclf():
    data, _gold = _derive_clf(_load_train_df())
    return data


def load_textclf_with_gold():
    """Instructor helper: also returns the hidden test gold (for grading)."""
    return _derive_clf(_load_train_df())


def load_lm():
    df = _load_train_df()
    texts = [t.replace("\n", " ").strip() for t in df["comment_text"].dropna().tolist()]
    rnd = random.Random(SEED)
    rnd.shuffle(texts)
    sample = [t for t in texts if t][:N_LM]
    cut = int(len(sample) * 0.9)
    return sample[:cut], sample[cut:]


# ---------- course-provided synthetic canaries (NOT a dataset upload) ----------
_CANARIES = [
    ("Canary secret ID QX7-4410 belongs to Jordan Vask", 1),
    ("Canary secret ID ZL2-8830 belongs to Robin Teel", 1),
    ("Canary secret ID MM9-1207 belongs to Sasha Lund", 4),
    ("Canary secret ID PK3-6652 belongs to Noa Brandt", 4),
    ("Canary secret ID TT1-5098 belongs to Kai Mor", 16),
    ("Canary secret ID RB8-3321 belongs to Eli Fenn", 16),
    ("Canary secret ID WD5-7744 belongs to Max Oort", 64),
    ("Canary secret ID HJ6-9015 belongs to Liv Aas", 64),
]
def load_canaries():
    return [{"canary": c, "frequency": f} for c, f in _CANARIES]


# ---------- three deterministic "models" for A2 (derived, not uploaded) ----------
def load_predictions():
    """Three models' predictions over the validation split, generated deterministically
    (subgroup-dependent noise) so A2 has something to compare without extra training."""
    val = load_textclf()["validation"]
    labels = ["toxic", "nontoxic"]
    configs = {"A": (0.90, 0.88), "B": (0.92, 0.70), "C": (0.78, 0.80)}  # (acc on majority grp, on others)
    out = {}
    for name, (acc_hi, acc_lo) in configs.items():
        rows = []
        for r in val:
            h = int(hashlib.sha1(f"{name}:{r['id']}".encode()).hexdigest(), 16) / 16 ** 40
            acc = acc_hi if r["subgroup"] == "none" else acc_lo
            pred = r["label"] if h < acc else next(l for l in labels if l != r["label"])
            rows.append({"id": r["id"], "pred": pred})
        out[name] = rows
    return out


if __name__ == "__main__":
    d = load_textclf()
    print("textclf:", {k: len(v) for k, v in d.items()})
    tr, hv = load_lm()
    print("lm:", len(tr), len(hv), "| canaries:", len(load_canaries()),
          "| preds:", {k: len(v) for k, v in load_predictions().items()})
