"""A1 self-test: checks your four TODOs in a1.py on tiny inputs with hand-worked answers.
Offline: no data, no network (TULIP is replaced by the kit's fake "mock" TULIP).

    python selftest.py

Toy corpus used below. Token ids: a=0, b=1, c=2, d=3, so V = 4. <s> is the BOS padding symbol.
    training paragraphs:  [a b]   [a c]   [b]
Bigram events (history -> w):   <s>->a   a->b   <s>->a   a->c   <s>->b
Counts:
    c(<s>,a) = 2   c(<s>,b) = 1          ->  c(<s>) = 2 + 1 = 3
    c(a,b)   = 1   c(a,c)   = 1          ->  c(a)   = 1 + 1 = 2
    b, c, d never occur as a history     ->  c(b) = c(c) = c(d) = 0

ADD-K with k = 1, V = 4:   P(w|h) = (c(h,w) + k) / (c(h) + k*V)
    P(a|<s>) = (2 + 1) / (3 + 1*4) = 3/7
    P(b|a)   = (1 + 1) / (2 + 4)   = 2/6 = 1/3
    P(d|a)   = (0 + 1) / (2 + 4)   = 1/6          (seen history, unseen word)
    P(a|b)   = (0 + 1) / (0 + 4)   = 1/4 = 1/V    (history b never seen)
    sum over w of P(w|a) = (2 + 2 + 1 + 1) / 6 = 1
    paragraph [a b d]: NLL = -ln P(a|<s>) - ln P(b|a) - ln P(d|b) = -ln(3/7) - ln(1/3) - ln(1/4) = 3.3322045...
ADD-K with k = 0.01:  P(a|<s>) = (2 + 0.01) / (3 + 0.04) = 2.01 / 3.04
ADD-K trigram (optional, order 3, pad with <s> <s>), k = 1:
    P(a|<s>,<s>) = (2 + 1) / (3 + 4) = 3/7      P(b|<s>,a) = (1 + 1) / (2 + 4) = 1/3
    P(c|a,b)     = 1/4                           (history (a,b) never seen)
INTERPOLATED KNESER-NEY, discount 0.75 (optional; only if you implement it):
    continuation counts N1+(.w): a=1 {<s>}, b=2 {<s>,a}, c=1 {a}, d=0; total 4; 3 word types seen
    P_uni(w) = max(N1+(.w) - 0.75, 0)/4 + 0.75*3/4 * 1/V  ->  a=0.203125  b=0.453125  c=0.203125  d=0.140625
    P(a|<s>) = (2 - 0.75)/3 + 0.75*2/3 * P_uni(a) = 0.518229166...
    P(b|a)   = (1 - 0.75)/2 + 0.75*2/2 * P_uni(b) = 0.46484375        P(a|b) = P_uni(a) = 0.203125
"""
import math, os, sys, traceback

KIT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, KIT)

A, B, C, D = 0, 1, 2, 3
TOY = [[A, B], [A, C], [B]]
results = []          # (status, name): status in PASS / FAIL / TODO / OPT


TODO_HINTS = {
    "NGramLM.fit": "write NGramLM.fit (counting c(h, w) and c(h)); the toy counts are worked out at the top of selftest.py",
    "NGramLM.prob": "write NGramLM.prob: the add-k formula from the NGramLM docstring (= the Definitions box)",
    "NGramLM.sample": "write NGramLM.sample: see its docstring (seeded rng, one draw from P(w|h) per step)",
    "doc_nll": "write doc_nll: see its docstring (the TULIP rule of the Definitions box)",
}


def check(name, fn, optional=False):
    try:
        msgs = [m for m in fn() if m]
    except NotImplementedError as e:
        results.append(("OPT" if optional else "TODO", name))
        todo = str(e).replace("TODO: ", "")
        print(f"{'!' if optional else '✗'} {name}: not implemented yet ({todo})" + ("  [optional]" if optional else ""))
        if not optional and todo in TODO_HINTS:
            print(f"      - hint: {TODO_HINTS[todo]}")
        return
    except Exception as e:
        msgs = [f"your code raised {type(e).__name__}: {e}"]
        tb = traceback.extract_tb(sys.exc_info()[2])
        mine = [f for f in tb if f.filename.endswith("a1.py")]
        if mine:
            msgs.append(f"(in a1.py, line {mine[-1].lineno}: {mine[-1].line})")
    if msgs:
        results.append(("OPT" if optional else "FAIL", name))
        print(f"{'!' if optional else '✗'} {name}" + ("  [optional]" if optional else ""))
        for m in msgs:
            print(f"      - {m}")
    else:
        results.append(("PASS", name))
        print(f"✓ {name}")


def close(got, exp, what, tol=1e-9):
    if isinstance(got, bool) or not isinstance(got, (int, float)) or not math.isfinite(got):
        return f"{what}: expected {exp:.10f}, got {got!r}"
    return None if abs(got - exp) <= tol * max(1.0, abs(exp)) else f"{what}: expected {exp:.10f}, got {got:.10f}"


def main():
    try:
        import a1 as S
    except Exception as e:
        print(f"✗ could not import a1.py: {type(e).__name__}: {e}"); return 1
    BOS = S.BOS

    # ---------------- NGramLM.fit + NGramLM.prob (add-k)
    def addk_bigram():
        m = S.NGramLM(2, "add_k", 4, k=1).fit(TOY)
        if m is None:
            return ["fit() must return self (so that NGramLM(...).fit(docs) gives the model)"]
        got = m.prob((BOS,), A)
        out = [close(got, 3 / 7, "P(a|<s>)"), close(m.prob((A,), B), 1 / 3, "P(b|a)"),
               close(m.prob((A,), D), 1 / 6, "P(d|a) (seen history, unseen word)")]
        if out[0] and isinstance(got, float) and abs(got - 2 / 3) < 1e-9:
            out.append("hint: 2/3 is the unsmoothed estimate c(h,w)/c(h); add-k adds k to the count and k*V to c(h)")
        if out[0] and isinstance(got, float) and abs(got - 3 / 6) < 1e-9:
            out.append("hint: is <s> counted as a history? Every paragraph's first token is predicted from <s>")
        return out

    def addk_k():
        m = S.NGramLM(2, "add_k", 4, k=0.01).fit(TOY)
        return [close(m.prob((BOS,), A), 2.01 / 3.04, "P(a|<s>) with k=0.01 (does prob() use self.k?)")]

    def unseen_history():
        m = S.NGramLM(2, "add_k", 4, k=0.1).fit(TOY)
        return [close(m.prob((B,), A), 1 / 4, "P(a|b): history b never seen in training, so P must be 1/V"),
                close(m.prob((D,), D), 1 / 4, "P(d|d): unseen history, unseen word, still 1/V")]

    def normalised():
        msgs = []
        for k in (1, 0.01):
            m = S.NGramLM(2, "add_k", 4, k=k).fit(TOY)
            for h, name in (((BOS,), "<s>"), ((A,), "a"), ((B,), "b (unseen)")):
                s = sum(m.prob(h, w) for w in range(4))
                e = close(s, 1.0, f"k={k}: sum over the V=4 words of P(w|{name})")
                if e:
                    msgs.append(e + "  hint: the denominator must be c(h) + k*V, with c(h) summed over ALL words after h")
        return msgs[:3]

    def nll_toy():
        m = S.NGramLM(2, "add_k", 4, k=1).fit(TOY)
        return [close(m.nll([A, B, D]), -math.log(3 / 7) - math.log(1 / 3) - math.log(1 / 4),
                      "NLL of paragraph [a b d] (uses your prob(); the provided nll() just sums -ln P)")]

    def addk_trigram():
        m = S.NGramLM(3, "add_k", 4, k=1).fit(TOY)
        return [close(m.prob((BOS, BOS), A), 3 / 7, "trigram P(a|<s>,<s>)"),
                close(m.prob((BOS, A), B), 1 / 3, "trigram P(b|<s>,a)"),
                close(m.prob((A, B), C), 1 / 4, "trigram P(c|a,b) (unseen history)")]

    def kn_bigram():
        m = S.NGramLM(2, "interpolated_kn", 4, discount=0.75).fit(TOY)
        return [close(m.prob((BOS,), A), 1.25 / 3 + 0.5 * 0.203125, "KN P(a|<s>)"),
                close(m.prob((A,), B), 0.46484375, "KN P(b|a)"), close(m.prob((B,), A), 0.203125, "KN P(a|b)"),
                close(sum(m.prob((BOS,), w) for w in range(4)), 1.0, "KN sum over w of P(w|<s>)")]

    # ---------------- NGramLM.sample
    def sample_valid():
        m = S.NGramLM(2, "add_k", 4, k=1).fit(TOY)
        s = m.sample([A], max_tokens=7, seed=1)
        if not isinstance(s, list):
            return [f"sample() must return a list of token ids, got {type(s).__name__}"]
        msgs = []
        if len(s) != 7:
            msgs.append(f"asked for max_tokens=7, got {len(s)} ids. There is no end token, so every step adds one "
                        "token; return only the NEW ids (not the prompt)")
        if any(isinstance(x, bool) or not isinstance(x, int) or not 0 <= x < 4 for x in s):
            msgs.append(f"every sampled id must be an int in range(V) = 0..3, got {s} (never BOS)")
        if m.sample([A], max_tokens=7, seed=1) != s:
            msgs.append("the same seed gave a different sample: use random.Random(seed) as the only randomness")
        outs = {tuple(m.sample([A], max_tokens=7, seed=i)) for i in range(10)}
        if len(outs) == 1:
            msgs.append("10 different seeds gave the same sample: are you taking the most likely token (greedy)? "
                        "Temperature 1.0 means drawing from the distribution")
        return msgs

    def sample_history():
        chain = [[A, B, C, D]] * 5                 # a->b->c->d, nearly certain with a tiny k
        m = S.NGramLM(2, "add_k", 4, k=1e-9).fit(chain)
        s = m.sample([A], max_tokens=3, seed=0)
        if list(s) != [B, C, D]:
            return [f"after the prompt [a], training text a b c d with k=1e-9 should continue with [b, c, d], got {s}. "
                    "hint: the history of each new token is the token(s) just before it, including tokens you "
                    "sampled yourself"]
        m2 = S.NGramLM(2, "add_k", 4, k=1e-9).fit([[A, B]] * 5)
        s2 = m2.sample([], max_tokens=1, seed=0)
        if list(s2) != [A]:
            return [f"with an empty prompt the first history is (<s>,): training [a b] should give [a], got {s2}"]
        return []

    def sample_distribution():
        m = S.NGramLM(2, "add_k", 4, k=1e-9).fit(TOY)      # P(b|a) = P(c|a) = 1/2, P(a|a), P(d|a) ~ 0
        firsts = [m.sample([A], max_tokens=1, seed=i)[0] for i in range(400)]
        nb, nc = firsts.count(B), firsts.count(C)
        if nb + nc != 400:
            return [f"after [a], only b or c are possible (k ~ 0), but {400 - nb - nc}/400 samples were something else"]
        if not 150 <= nb <= 250:
            return [f"after [a], b and c each have probability 1/2, but 400 seeds gave b {nb} times and c {nc} times. "
                    "Draw from P(w|h) itself (weights = probabilities), not from the counts of another history"]
        m2 = S.NGramLM(2, "add_k", 4, k=1).fit(TOY)       # unseen history -> uniform 1/4
        firsts = [m2.sample([D], max_tokens=1, seed=i)[0] for i in range(400)]
        if min(firsts.count(w) for w in range(4)) < 60:
            return [f"after the unseen history [d] every word has P = 1/4, but 400 seeds gave counts "
                    f"{[firsts.count(w) for w in range(4)]}. Draw over ALL w in range(V)"]
        return []

    # ---------------- doc_nll (TULIP protocol), against the mock TULIP client
    def doc_nll_protocol():
        from tulip_client import TulipClient
        text = "The cat sat on the mat, and then it slept."
        scored = TulipClient(mock=True).score([text])[0]       # [(token, logprob), ...] as for real TULIP
        ref = -sum(lp for _, lp in scored)
        got = S.doc_nll(scored)
        msgs = [close(got, ref, "doc_nll on a mock-TULIP paragraph", tol=1e-9)]
        if msgs[0] and isinstance(got, (int, float)):
            if abs(got + ref) < 1e-6:
                msgs.append("hint: the result has the wrong sign. An NLL is MINUS the sum of the log-probs (>= 0)")
            elif abs(got - (ref + scored[0][1])) < 1e-6:
                msgs.append("hint: you skipped the first token. The client already removed the start-of-text "
                            "token; every entry is a paragraph token and counts")
            elif abs(got - (ref + scored[-1][1])) < 1e-6:
                msgs.append("hint: you skipped the last token. There is no end token in the list; every entry counts")
            elif abs(got - ref / math.log(2)) < 1e-6:
                msgs.append("hint: keep natural logs (nats); do not convert to bits")
            elif abs(got - ref / len(scored)) < 1e-6:
                msgs.append("hint: return the TOTAL NLL of the paragraph, not the average per token")
        msgs.append(close(S.doc_nll([("Hi", -0.5), (" there", -1.25)]), 1.75, "doc_nll([('Hi', -0.5), (' there', -1.25)])"))
        msgs.append(close(S.doc_nll([]), 0.0, "doc_nll([]) (an empty list scores 0)"))
        try:
            r = S.doc_nll([("Hi", -0.5), (" there", None)])
            msgs.append(f"a token with logprob None must raise ValueError (it was not scored), but doc_nll returned {r!r}")
        except ValueError:
            pass
        except NotImplementedError:
            raise
        except Exception as e:
            msgs.append(f"a None logprob should raise ValueError, got {type(e).__name__}. Check for None explicitly")
        return msgs

    # ---------------- provided parts (should always pass)
    def tokenizer_lossless():
        tok = S.train_tokenizer(["the cat sat on the mat", "café  naïve 😀\tok", "Tikal @-@ 1 @,@ 000"] * 20, 300)
        msgs = []
        for x in ["  two  spaces", "café 😀 ünïcödé", "tab\there", "Hello world.", "1 @,@ 000"]:
            ids = S.encode(tok, [x])[0]
            if tok.decode(ids) != x:
                msgs.append(f"tokenizer is not lossless on {x!r} -> {tok.decode(ids)!r} (did you edit train_tokenizer?)")
        return msgs

    def mock_client():
        import tulip_client as tc
        text = "  Leading spaces, émoji 😀 and a final dot."
        sc = tc.TulipClient(mock=True).score([text])[0]
        msgs = []
        if len(sc) != len(tc.mock_tokenize(text)) or not all(isinstance(t, str) and t.isdigit() for t, _ in sc):
            msgs.append("the mock client should return one (token id, logprob) per text token (did you edit tulip_client.py?)")
        return msgs

    def scoring_parser():
        """The client's parser of TULIP's answer (nvext.prompt_logprobs): it must refuse broken answers."""
        import tulip_client as tc
        good = tc.mock_score_response(tc.BOS_TEXT + "Hello world.")
        first_scored = [{"2": {"logprob": -3.0, "rank": 9}}] + good["nvext"]["prompt_logprobs"][1:]
        bad_cases = [
            ("no nvext (scoring not enabled)", {k: v for k, v in good.items() if k != "nvext"}, tc.ScoringNotEnabled),
            ("entry 0 not null (no <bos> context)", dict(good, nvext={"prompt_logprobs": first_scored}), tc.ProtocolError),
            ("entry count != usage.prompt_tokens", dict(good, usage=dict(good["usage"], prompt_tokens=99)), tc.ProtocolError),
        ]
        msgs = []
        if len(tc.parse_prompt_logprobs(good, "Hello world.")) != len(tc.mock_tokenize("Hello world.")):
            msgs.append("parse_prompt_logprobs drops or adds tokens on a good answer (did you edit tulip_client.py?)")
        for name, j, exc in bad_cases:
            try:
                tc.parse_prompt_logprobs(j, "Hello world.")
                msgs.append(f"parse_prompt_logprobs accepted a broken answer: {name} (did you edit tulip_client.py?)")
            except exc as e:
                if exc is tc.ScoringNotEnabled and "not enabled" not in str(e):
                    msgs.append("the 'scoring not enabled' message is missing (did you edit tulip_client.py?)")
        try:
            tc.TulipClient(mock=True).score(["a <bos> inside"])
            msgs.append("score() accepted a text containing '<bos>' (did you edit tulip_client.py?)")
        except tc.SpecialTokenInText:
            pass
        return msgs

    print("NGramLM.fit + NGramLM.prob (add-k, task 2)")
    check("add-k bigram on the toy corpus", addk_bigram)
    check("add-k uses the k you pass in", addk_k)
    check("unseen history gives 1/V", unseen_history)
    check("P(w|h) sums to 1 over the V words", normalised)
    check("paragraph NLL on the toy corpus", nll_toy)
    check("add-k trigram (--order 3)", addk_trigram, optional=True)
    check("interpolated Kneser-Ney bigram", kn_bigram, optional=True)
    print("doc_nll (TULIP protocol, task 3)")
    check("doc_nll protocol cases (mock TULIP)", doc_nll_protocol)
    print("NGramLM.sample (task 5)")
    check("sample: valid ids, length, determinism", sample_valid)
    check("sample: history moves on with each new token", sample_history)
    check("sample: draws from P(w|h) over all V words", sample_distribution)
    print("provided parts")
    check("byte-level tokenizer is lossless", tokenizer_lossless)
    check("mock TULIP client", mock_client)
    check("TULIP answer parser refuses broken answers", scoring_parser)

    n_bad = sum(1 for r, _ in results if r in ("FAIL", "TODO"))
    n_opt = sum(1 for r, _ in results if r == "OPT")
    print()
    if n_bad == 0:
        print("✓ All required tests pass." + (f" ({n_opt} optional test(s) not passing: fine unless you use that option.)" if n_opt else "")
              + "\n  Next: python a1.py --student-number <yours>   (or add --mock to try the pipeline offline)")
    else:
        print(f"✗ {n_bad} required test(s) not passing yet. Fix them before the real run."
              + (f" ({n_opt} optional test(s) are only needed for --order 3 / Kneser-Ney.)" if n_opt else ""))
    return 1 if n_bad else 0


if __name__ == "__main__":
    sys.exit(main())
