"""DSAIT4090 local submission checker. Validates file names, schemas, and value
ranges BEFORE you submit (a passing check is a precondition for auto-grading).

    python check_submission.py A3 path/to/submission_dir_or_zip

It does NOT score correctness (that uses the hidden reference) — it catches format errors.
"""
import sys, os, json, csv, zipfile, tempfile, glob

LABELS = {"toxic", "nontoxic"}


def _find(root, name):
    hits = glob.glob(os.path.join(root, "**", name), recursive=True)
    return hits[0] if hits else None


def _csv(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def _need(cond, msg, errs):
    if not cond:
        errs.append(msg)


def check_A1(root, errs):
    p = _find(root, "a1_perplexity.json")
    _need(p, "missing a1_perplexity.json", errs)
    if not p:
        return
    d = json.load(open(p))
    for k in ("ngram_ppl", "gpt2_ppl"):
        _need(k in d and isinstance(d[k], (int, float)) and d[k] > 0, f"a1: key {k} missing or not >0", errs)


def check_A2(root, errs):
    m = _find(root, "a2_metrics.json")
    _need(m, "missing a2_metrics.json", errs)
    if m:
        d = json.load(open(m))
        models = d.get("models", {})
        _need(isinstance(models, dict) and len(models) >= 3,
              "a2_metrics.json needs a 'models' object with >=3 entries", errs)
        for model, md in (models.items() if isinstance(models, dict) else []):
            for metric in ("precision", "recall", "f1"):
                _need(isinstance(md.get(metric), dict) and {"macro", "micro"} <= set(md[metric]),
                      f"a2: models.{model}.{metric} needs macro & micro", errs)
            _need("f1_by_subgroup" in md, f"a2: models.{model} missing f1_by_subgroup", errs)
    e = _find(root, "a2_errors.csv")
    _need(e, "missing a2_errors.csv", errs)
    if e:
        rows = _csv(e)
        _need(len(rows) == 20, f"a2_errors.csv must have exactly 20 rows (got {len(rows)})", errs)
        _need({"id", "gold", "pred", "category"} <= set(rows[0].keys()), "a2_errors.csv needs id,gold,pred,category", errs)
        cats = {r["category"] for r in rows}
        _need(len(cats) >= 3, f"a2_errors.csv needs >=3 categories (got {len(cats)})", errs)


def _check_pred(root, fname, errs, required=True):
    p = _find(root, fname)
    if not p:
        _need(not required, f"missing {fname}", errs)
        return
    rows = _csv(p)
    _need({"id", "pred"} <= set(rows[0].keys()), f"{fname} needs columns id,pred", errs)
    bad = [r["pred"] for r in rows if r["pred"] not in LABELS]
    _need(not bad, f"{fname} has invalid labels e.g. {bad[:3]}", errs)


def check_A3(root, errs):
    _check_pred(root, "a3_pred_bow.csv", errs, True)
    _check_pred(root, "a3_pred_bert.csv", errs, True)
    _check_pred(root, "a3_pred_emb.csv", errs, False)  # optional rung


def check_A4(root, errs):
    e = _find(root, "a4_extraction.csv")
    _need(e, "missing a4_extraction.csv", errs)
    if e:
        rows = _csv(e)
        _need({"frequency", "extraction_rate"} <= set(rows[0].keys()),
              "a4_extraction.csv needs frequency,extraction_rate", errs)


def check_A5(root, errs):
    l = _find(root, "a5_latency.csv")
    _need(l, "missing a5_latency.csv", errs)
    if l:
        cols = {"prompt_tokens", "gen_tokens", "latency_s"}
        _need(cols <= set(_csv(l)[0].keys()), f"a5_latency.csv needs {sorted(cols)}", errs)
    b = _find(root, "a5_budget.json")
    _need(b, "missing a5_budget.json", errs)
    if b:
        d = json.load(open(b))
        need = {"tokens_in", "tokens_out", "est_total_tokens", "est_wallclock_min", "assumptions"}
        _need(need <= set(d), f"a5_budget.json needs {sorted(need)}", errs)


def check_A6(root, errs):
    p = _find(root, "a6_findings.pdf")
    _need(p and os.path.getsize(p) > 2000, "missing/empty a6_findings.pdf", errs)


CHECKS = {"A1": check_A1, "A2": check_A2, "A3": check_A3, "A4": check_A4, "A5": check_A5, "A6": check_A6}


def main():
    if len(sys.argv) != 3 or sys.argv[1] not in CHECKS:
        print("usage: python check_submission.py {A1..A6} <dir-or-zip>"); sys.exit(2)
    code, path = sys.argv[1], sys.argv[2]
    tmp = None
    if path.endswith(".zip"):
        tmp = tempfile.mkdtemp(); zipfile.ZipFile(path).extractall(tmp); root = tmp
    else:
        root = path
    errs = []
    CHECKS[code](root, errs)
    # reflection is required for all
    if not _find(root, "reflection.md") and not _find(root, "reflection.pdf"):
        errs.append("missing reflection.md/.pdf")
    if errs:
        print(f"✗ {code}: {len(errs)} issue(s):")
        for e in errs:
            print("  -", e)
        sys.exit(1)
    print(f"✓ {code}: format OK — ready to submit.")


if __name__ == "__main__":
    main()
