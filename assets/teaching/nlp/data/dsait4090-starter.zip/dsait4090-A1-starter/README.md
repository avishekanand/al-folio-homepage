# DSAIT4090 A1: Tokenization and Statistical Language Modelling (starter kit)

The full task is in the assignment text (Brightspace). This folder is everything you need: the data ships
with the kit, so nothing is downloaded (the only download is Gemma 4's tokenizer, about 30 MB, once; see below).

```
a1.py                 the scaffold: you write 4 TODOs, it does everything else and writes submission/
selftest.py           checks your TODOs offline on a toy corpus with hand-worked answers
tulip_check.py        checks your TULIP set-up (key, VPN, model, generation, scoring)
tulip_client.py       the only way the kit talks to TULIP (pacing, cache, retries, budget)     (do not edit)
load_data.py          load_lm(student_number), lm_dev_split(train), load_prompts()            (do not edit)
data/                 the WikiText-103 paragraphs and the 5 prompts (see data/README.md)       (do not edit)
findings.md           the two findings questions Q1-Q2: answer them with YOUR numbers
reflection.md         the reflection questions + AI-use declaration
make_zip.py           builds A1_<studentnumber>.zip and runs the checker
check_submission.py   the format checker (make_zip.py runs it for you)
```

## Set-up (5 minutes, once)

1. **Python 3.12** in a fresh virtual environment, then the pinned packages (no PyTorch, no GPU needed).
   Create it **inside this kit folder** as `.venv/` (run the commands from the kit folder). It is only for your
   own machine: never include it in your submission (`make_zip.py` leaves it out).
   ```bash
   python3.12 -m venv .venv
   source .venv/bin/activate            # Windows: .venv\Scripts\activate
   python -m pip install -r requirements.txt
   ```
2. **Your TULIP key.** Copy `.env.example` to `.env` and put your personal key after
   `TUDELFT_TULIP_API_KEY=` (no quotes, no spaces). Never share, commit or upload `.env`.
3. **Network.** TULIP is only reachable from the TU Delft network or through **eduVPN**. So is TULIP's
   own documentation: https://docs.tulip.tudelft.nl/
4. **Check:**
   ```bash
   python tulip_check.py
   ```
   Every item shows ✓ or ✗ with a fix: key, network, model, generation and input scoring (TULIP's
   log-probabilities of a short text). All must pass before the real run. To work without TULIP (no VPN,
   or TULIP down), add `--mock` to `a1.py` (or set `TULIP_MOCK=1`): same pipeline, fake TULIP numbers.

## Do the assignment

```bash
python selftest.py                                  # write the 4 TODOs in a1.py until everything is ✓
python a1.py --student-number <n>                   # the real run: about 2-3 minutes (TULIP part ~75-90 s)
python make_zip.py <n>                              # builds A1_<n>.zip, checks it, prints the file to upload
```

- **The 4 TODOs** in `a1.py`: `NGramLM.fit`, `NGramLM.prob` (add-k), `doc_nll` (TULIP protocol) and
  `NGramLM.sample`. Their docstrings are the Definitions box of the assignment.
- `a1.py` trains the byte-level BPE tokenizers (8000, plus the sweep 257 / 1000 / 8000), picks k on the dev
  part from {1, 0.1, 0.01, 0.001} and refits on all training text, computes per-token and per-byte
  perplexity of both models on your 300 held-out paragraphs, scores them on TULIP, generates
  `samples.txt` (5 prompts, at most 40 tokens, temperature 1.0, both models) and writes `submission/`.
  It ends with a table of every number the findings questions need, and with the 10 tokens each model
  finds most surprising (highest NLL, with a bit of context): evidence for Q2.
- **TULIP's model** (alias `chat`) is **Gemma 4 31B**, an instruction-tuned (chat) model served with 4-bit
  weights (checkpoint `google/gemma-4-31B-it-qat-w4a16-ct`). For scoring, the kit's client sends **one
  paragraph per request at a polite pace** (at most 4 requests per second, at most 2 at a time; TULIP allows
  300 requests per minute per key) and **caches** every answer: scoring your 300 paragraphs takes about
  75-90 s the first time and sends 0 requests after that. It also retries politely and stops if a run would
  use more than 400,000 tokens. For generation the kit asks the chat model (through the chat endpoint, with
  its "thinking" mode off) to continue each prompt; your n-gram simply samples the next tokens.
- TULIP returns token **ids**, not text. To show TULIP's most surprising tokens as text, `a1.py` downloads
  Gemma 4's tokenizer (`google/gemma-4-31B-it`, about 30 MB) once into your HuggingFace cache
  (`~/.cache/huggingface`). If that download fails, it prints the token ids instead, with a note; nothing
  else depends on it.
- `--mock` runs the same pipeline with a fake TULIP and no network: good for development, but the TULIP
  numbers and samples are fake (the checker warns). Your final run must be without `--mock`.
- Optional (no extra points, never penalised): `--order 3` (trigram) and `--smoothing interpolated_kn`
  (Kneser-Ney; you add it to `fit`/`prob` yourself, `selftest.py` has optional tests for it).
- Use the same student number everywhere: your held-out set, and therefore your grade, depend on it.
- Answer `findings.md` (2-4 sentences per question, under the quoted question) and `reflection.md`.
- In the checker output, ✗ lines are errors you must fix; ! lines are only hints.

## What a1.py writes (`submission/`)

| file | content |
|---|---|
| `a1_results.json` | the numbers below |
| `tokenizer.json` | your 8000-vocab tokenizer |
| `sweep/tokenizer_257.json`, `sweep/tokenizer_1000.json` | the sweep tokenizers (8000 is `tokenizer.json`) |
| `samples.txt` | 5 prompts, one n-gram and one TULIP continuation each |

`a1_results.json`:

```text
ngram_ppl_token, ngram_ppl_byte          8k n-gram on your 300 held-out paragraphs
tulip_ppl_token, tulip_ppl_byte          TULIP on the same paragraphs
meta:
  student_number, n_heldout_docs (300), n_bytes (UTF-8 bytes of the 300 paragraphs)
  tokenizer_file, vocab_size, avg_tokens_per_doc (8k n-gram tokens per held-out paragraph)
  order (2 or 3), smoothing (add_k or interpolated_kn), k (or discount), grid, dev_results {k: dev PPL/token}
  ngram_n_tokens, ngram_total_nll, tulip_n_tokens, tulip_total_nll, tulip_model, tulip_mode (real / mock)
  kit_version
  surprising_tokens: {ngram: [...], tulip: [...], tulip_note}: the 10 highest-NLL held-out tokens per model,
         each with token, context, nll, paragraph, position (tulip entries also token_id)
  sweep: one entry per vocab size 257 / 1000 / 8000 with vocab_size, tokenizer_file, k, dev_results,
         n_tokens, ppl_token, ppl_byte, bytes_per_token, unseen_bigram_rate
samples: file, n_prompts (5), max_tokens (40), temperature (1.0), ngram_seeds, tulip_model
```

Per-token and per-byte perplexity come from the same total NLL, so for every model
`ln PPL_byte = ln PPL_token * N_tokens / N_bytes`; the checker verifies this (±0.5%).

## What stays on your machine

- **TULIP requests** (your held-out paragraphs, the 5 prompts, and `tulip_check.py`'s two test sentences)
  are the only text that leaves your machine. They go to TU Delft's own TULIP service. Each request
  carries the headers `X-Course: DSAIT4090`, `X-Assignment: A1`, `X-Kit-Version` and `X-Client-Id`, a
  truncated hash of your student number (never the number itself).
- **`.tulip_cache/`** stores TULIP's answers (token ids and log-probabilities, generated text) on your disk,
  keyed by a hash of model, mode, text and settings. Re-runs never re-send a cached text, so after one
  successful run you can work offline. Delete the folder to start over.
- **`tulip_usage.jsonl`** logs one line per request: time, mode, number of texts, prompt/completion tokens,
  latency, status, and whether it was a cache hit. No text and no key.
- Your key is read from `.env` and is never printed or logged. `make_zip.py` never puts `.env`, the cache,
  the usage log or the data into the zip.
- Settings (environment variables, all optional): `TULIP_MOCK=1` (fake TULIP), `TULIP_ENV_FILE` (another
  `.env` path), `TULIP_MIN_INTERVAL` (seconds between request starts, default 0.25 = 4 requests/s; do not go
  below 0.2, TULIP's limit is 300 requests per minute), `TULIP_MAX_TOKENS_PER_RUN` (default 400000; the run
  stops with a clear message beyond it).

## Troubleshooting

- `No module named 'tokenizers'` / `'openai'`: activate your virtual environment.
- `Cannot connect to TULIP ... eduVPN?`: connect to eduVPN or the campus network; `python tulip_check.py`.
- `TULIP rejected your key`: check `.env` (the key from Brightspace, no quotes).
- `TULIP is unavailable` / `rate-limiting` (HTTP 429): the client already waits and retries; if it still
  stops, wait a minute and re-run: cached results stay valid. If TULIP is down close
  to the deadline, report it on the course forum.

## Data and licence

The text is from **WikiText-103** (Merity et al., 2016, *Pointer Sentinel Mixture Models*), HuggingFace
`Salesforce/wikitext`, configuration `wikitext-103-raw-v1`, derived from Wikipedia and licensed under
**CC BY-SA 3.0**. The kit ships a small derived sample (same licence); `data/README.md` describes exactly how
it was made. The n-gram counting must be your own code (no `nltk.lm`, kenlm or similar).
