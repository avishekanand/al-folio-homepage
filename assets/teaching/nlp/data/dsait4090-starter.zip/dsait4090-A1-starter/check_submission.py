"""DSAIT4090 A1 submission checker. make_zip.py runs it for you; you can also run it yourself:

    python check_submission.py A1_1234567.zip

✗ = error: fix it, otherwise your submission cannot be graded correctly.
! = warning: a hint to double-check something; it does not block grading.
The checker does NOT tell you whether your perplexities are right: the grader recomputes them.
"""
import json, math, os, re, shutil, sys, tempfile, zipfile

KIT = os.path.dirname(os.path.abspath(__file__))
OK, ERR, WARN = "✓", "✗", "!"
errors, warnings, notes, TMP = [], [], [], []
N_HELDOUT, N_PROMPTS, MAX_TOKENS, TEMPERATURE, MAIN_VOCAB = 300, 5, 40, 1.0, 8000
SWEEP = (257, 1000, 8000)
TOL = 0.005                                     # consistency identity: +-0.5%
REQUIRED_TOP = ("ngram_ppl_token", "ngram_ppl_byte", "tulip_ppl_token", "tulip_ppl_byte")
REQUIRED_META = ("student_number", "n_heldout_docs", "n_bytes", "vocab_size", "avg_tokens_per_doc", "order",
                 "smoothing", "dev_results", "ngram_n_tokens", "tulip_n_tokens", "sweep", "kit_version", "tulip_mode")
REQUIRED_FILES = ("a1_results.json", "tokenizer.json", "sweep/tokenizer_257.json", "sweep/tokenizer_1000.json",
                  "samples.txt", "findings.md", "reflection.md", "code/a1.py")
LOSSLESS_PROBES = ["Hello world.", "  two  leading spaces", "café naïve ünïcödé", "emoji 😀 and tab\tend",
                   "The 1 @,@ 000 @-@ year war ( 1337 – 1453 ) ."]


def E(msg): errors.append(msg)
def W(msg): warnings.append(msg)


def num(x):
    return isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x)


def read_text(path):
    raw = open(path, "rb").read()
    for enc in ("utf-8-sig", "utf-16"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode("latin-1")


def strip_comments(t):
    return re.sub(r"(?s)<!--.*?-->", "", t)


# ------------------------------------------------------------------ the zip itself
def open_submission(path):
    """Returns (root_dir, zip_name or None, namelist). Never raises."""
    if not os.path.exists(path):
        E(f"'{path}' does not exist. Give the path to your A1_<studentnumber>.zip (make_zip.py builds it)."); return None, None, []
    if os.path.isdir(path):
        W("you gave a folder, not a zip: fine for testing, but upload the zip that make_zip.py builds.")
        names = [os.path.relpath(os.path.join(dp, f), path).replace(os.sep, "/") for dp, _, fs in os.walk(path) for f in fs]
        return path, None, names
    name = os.path.basename(path)
    if not re.fullmatch(r"A1_\d+\.zip", name):
        E(f"the zip is named '{name}' but must be A1_<studentnumber>.zip, digits only (e.g. A1_1234567.zip). "
          "`python make_zip.py <studentnumber>` names it for you.")
    try:
        with zipfile.ZipFile(path) as z:
            names = z.namelist()
            bad = [n for n in names if n.startswith("/") or ".." in n.split("/") or ":" in n]
            if bad:
                E(f"the zip contains unsafe paths like {bad[0]!r}; rebuild it with make_zip.py."); return None, name, names
            tmp = tempfile.mkdtemp(prefix="a1check_")
            TMP.append(tmp)
            z.extractall(tmp)
    except zipfile.BadZipFile:
        E(f"'{name}' is not a valid zip file (corrupt, or not a zip at all). Rebuild it with "
          "`python make_zip.py <studentnumber>`."); return None, name, []
    except Exception as e:
        E(f"could not open '{name}' ({type(e).__name__}). Rebuild it with make_zip.py."); return None, name, []
    root = tmp
    if not os.path.exists(os.path.join(root, "a1_results.json")):
        entries = [e for e in os.listdir(root) if not e.startswith("__MACOSX")]
        if len(entries) == 1 and os.path.isdir(os.path.join(root, entries[0])):
            W(f"your files are inside a folder '{entries[0]}/' in the zip; they should be at the top level. "
              "Accepted, but make_zip.py does this right for you.")
            root = os.path.join(root, entries[0])
            names = [n[len(entries[0]) + 1:] for n in names if n.startswith(entries[0] + "/")]
    return root, name, names


def check_forbidden(names):
    base = lambda n: n.rstrip("/").split("/")[-1]
    env = [n for n in names if base(n) == ".env" or base(n).endswith(".env")]
    if env:
        E(f"the zip contains {env[0]!r}: that is your SECRET TULIP KEY. Remove it (make_zip.py never adds it) and "
          "never share it. If you already uploaded it somewhere, ask for a new key.")
    cache = [n for n in names if ".tulip_cache" in n.split("/")]
    if cache:
        E("the zip contains the TULIP cache (.tulip_cache/). Leave it out: make_zip.py does.")
    data = [n for n in names if "data" in n.split("/")[:-1] or n.endswith((".json.gz", ".parquet", ".arrow", ".csv"))]
    if data:
        E(f"the zip contains data files (e.g. {data[0]!r}). Do not include the data; make_zip.py leaves it out.")
    pyc = [n for n in names if n.endswith(".pyc") or "__pycache__" in n.split("/")]
    if pyc:
        E(f"the zip contains compiled Python files (e.g. {pyc[0]!r}). Leave out __pycache__/ and *.pyc.")
    env = [n for n in names if any(p in (".venv", "venv", "env", "site-packages") for p in n.split("/")[:-1])]
    if env:
        E(f"the zip contains a virtual environment (e.g. {env[0]!r}). Never include .venv/: build the zip with "
          "make_zip.py, which leaves it out.")
    if any(base(n) == "tulip_usage.jsonl" for n in names):
        W("the zip contains tulip_usage.jsonl; it is not needed (and not graded).")


def check_required(root):
    for f in REQUIRED_FILES:
        if f == "reflection.md" and os.path.exists(os.path.join(root, "reflection.pdf")):
            W("reflection.pdf instead of reflection.md: accepted, but the checker cannot read a PDF. Make sure it "
              "has the three questions and the AI-use declaration.")
            continue
        if not os.path.exists(os.path.join(root, *f.split("/"))):
            fix = {"findings.md": "it is the kit's findings.md with your answers; run make_zip.py from the kit folder",
                   "reflection.md": "it is the kit's reflection.md with your answers; run make_zip.py from the kit folder",
                   "code/a1.py": "make_zip.py copies your a1.py into code/; run it from the kit folder"}.get(
                f, "a1.py writes it into submission/: re-run a1.py, then make_zip.py")
            E(f"missing {f} in the zip ({fix}).")


# ------------------------------------------------------------------ a1_results.json
def load_json(root):
    p = os.path.join(root, "a1_results.json")
    if not os.path.exists(p):
        return None
    txt = read_text(p).strip()
    if not txt:
        E("a1_results.json is empty. Re-run `python a1.py --student-number <yours>`."); return None
    try:
        d = json.loads(txt)
    except json.JSONDecodeError as e:
        E(f"a1_results.json is not valid JSON (line {e.lineno}, column {e.colno}: {e.msg}). Do not edit it by "
          "hand; re-run a1.py."); return None
    if not isinstance(d, dict):
        E("a1_results.json must contain a JSON object {...}; re-run a1.py."); return None
    return d


def check_numbers(d):
    for k in REQUIRED_TOP:
        if k not in d:
            E(f"a1_results.json: missing '{k}'. Re-run a1.py.")
        elif not num(d[k]):
            E(f"a1_results.json: '{k}' must be a finite number, got {d[k]!r}.")
        elif d[k] <= 1:
            E(f"a1_results.json: '{k}' = {d[k]}, but a perplexity is always > 1. Did you store a log or an NLL?")
    if all(num(d.get(k)) and d[k] > 1 for k in REQUIRED_TOP):
        for m in ("ngram", "tulip"):
            if not d[f"{m}_ppl_byte"] < 256:
                E(f"{m}: per-byte perplexity {d[f'{m}_ppl_byte']:.2f} >= 256, impossible (a byte has only 256 values).")
            if d[f"{m}_ppl_byte"] > d[f"{m}_ppl_token"]:
                W(f"{m}: per-byte PPL > per-token PPL. Every token covers >= 1 byte, so per-byte should be the smaller one.")


def identity(ptok, pbyte, ntok, nbytes, what):
    """ln PPL_byte = ln PPL_token * N_tokens / N_bytes  (both come from the same total NLL)."""
    if not all(num(x) for x in (ptok, pbyte, ntok, nbytes)) or ptok <= 1 or pbyte <= 1 or ntok <= 0 or nbytes <= 0:
        return
    lhs, rhs = math.log(pbyte), math.log(ptok) * ntok / nbytes
    if abs(lhs - rhs) > TOL * max(abs(lhs), abs(rhs)):
        E(f"{what}: ln PPL_byte = {lhs:.4f} but ln PPL_token * N_tokens / N_bytes = {rhs:.4f} (more than 0.5% apart). "
          "Both must come from the same total NLL with the N_tokens and N_bytes in meta; do not edit the numbers.")


def check_meta(d, zip_sn):
    m = d.get("meta")
    if not isinstance(m, dict):
        E("a1_results.json has no 'meta' object. a1.py writes it; re-run it."); return None
    miss = [k for k in REQUIRED_META if k not in m]
    if miss:
        E(f"meta is missing {miss}. Re-run a1.py (it fills these in).")
    sn = str(m.get("student_number", "")).strip()
    if not sn.isdigit():
        E(f"meta.student_number must be your student number (digits), got {m.get('student_number')!r}.")
    elif zip_sn and int(sn) != int(zip_sn):
        E(f"meta.student_number {sn} does not match the zip name A1_{zip_sn}.zip. Your held-out set depends on this "
          "number: run a1.py with YOUR number and name the zip after it (make_zip.py <same number>).")
    for k, lo in (("n_heldout_docs", 1), ("n_bytes", 1), ("vocab_size", 1), ("ngram_n_tokens", 1), ("tulip_n_tokens", 1)):
        if k in m and (not num(m[k]) or m[k] < lo or int(m[k]) != m[k]):
            E(f"meta.{k} must be a positive whole number, got {m[k]!r}.")
    if num(m.get("n_heldout_docs")) and m["n_heldout_docs"] != N_HELDOUT:
        E(f"meta.n_heldout_docs = {m['n_heldout_docs']}, but load_lm() returns {N_HELDOUT} held-out paragraphs.")
    if num(m.get("n_bytes")) and not 120_000 <= m["n_bytes"] <= 260_000:
        W(f"meta.n_bytes = {m['n_bytes']} looks off (300 held-out paragraphs are about 190,000 bytes).")
    if num(m.get("avg_tokens_per_doc")) and num(m.get("ngram_n_tokens")) and num(m.get("n_heldout_docs")) and m["n_heldout_docs"]:
        if abs(m["avg_tokens_per_doc"] - m["ngram_n_tokens"] / m["n_heldout_docs"]) > 0.01:
            W("meta.avg_tokens_per_doc is not ngram_n_tokens / n_heldout_docs.")
    if m.get("order") not in (2, 3):
        E(f"meta.order must be 2 (bigram) or 3 (trigram), got {m.get('order')!r}.")
    sm = m.get("smoothing")
    if sm not in ("add_k", "interpolated_kn"):
        E(f"meta.smoothing must be 'add_k' or 'interpolated_kn', got {sm!r}.")
    param = "discount" if sm == "interpolated_kn" else "k"
    if sm in ("add_k", "interpolated_kn"):
        v = m.get(param)
        if not num(v) or v <= 0 or (param == "discount" and v >= 1):
            E(f"meta.{param} must be a number in the allowed range for {sm}, got {v!r}.")
    dr = m.get("dev_results")
    if isinstance(dr, dict) and dr:
        try:
            vals = {float(k): v for k, v in dr.items()}
            if not all(num(v) and v > 1 for v in vals.values()):
                E("meta.dev_results must map each candidate to its dev per-token perplexity (> 1).")
            elif num(m.get(param)):
                best = min(vals, key=vals.get)
                if abs(best - m[param]) > 1e-9 * max(1.0, abs(best)):
                    W(f"meta.{param} = {m[param]} is not the candidate with the lowest dev perplexity ({best}).")
        except (TypeError, ValueError, AttributeError):
            E("meta.dev_results must map each candidate value to its dev per-token perplexity.")
    elif "dev_results" in m:
        E("meta.dev_results must be a non-empty object {candidate: dev per-token PPL}.")
    if m.get("tulip_mode") == "mock":
        W("tulip_mode is 'mock': your TULIP numbers and samples are FAKE. Re-run a1.py without --mock / TULIP_MOCK "
          "(on the TU Delft network or eduVPN, with your key in .env) and rebuild the zip.")
    elif m.get("tulip_mode") not in ("real", None):
        E(f"meta.tulip_mode must be 'real' or 'mock', got {m.get('tulip_mode')!r}.")
    if "kit_version" in m and not str(m.get("kit_version", "")).startswith("A1-"):
        W(f"meta.kit_version = {m.get('kit_version')!r} is not an A1 kit version.")
    identity(d.get("ngram_ppl_token"), d.get("ngram_ppl_byte"), m.get("ngram_n_tokens"), m.get("n_bytes"), "n-gram (8k)")
    identity(d.get("tulip_ppl_token"), d.get("tulip_ppl_byte"), m.get("tulip_n_tokens"), m.get("n_bytes"), "TULIP")
    if num(m.get("tulip_n_tokens")) and num(m.get("n_bytes")) and m["tulip_n_tokens"] > 0:
        r = m["n_bytes"] / m["tulip_n_tokens"]
        if not 2.0 <= r <= 8.0:
            W(f"TULIP averages {r:.2f} bytes per token in your meta, which is unusual; check that tulip_n_tokens counts "
              "exactly the scored paragraph tokens.")
    return m


def check_samples(d, root):
    s = d.get("samples")
    if not isinstance(s, dict):
        E("a1_results.json has no 'samples' object. Re-run a1.py.")
    else:
        if s.get("n_prompts") != N_PROMPTS:
            E(f"samples.n_prompts must be {N_PROMPTS}, got {s.get('n_prompts')!r}.")
        if s.get("max_tokens") != MAX_TOKENS:
            E(f"samples.max_tokens must be {MAX_TOKENS}, got {s.get('max_tokens')!r}.")
        if not num(s.get("temperature")) or abs(s["temperature"] - TEMPERATURE) > 1e-9:
            E(f"samples.temperature must be {TEMPERATURE}, got {s.get('temperature')!r}.")
    p = os.path.join(root, "samples.txt")
    if os.path.exists(p):
        t = read_text(p)
        n_ng, n_tl = len(re.findall(r"(?m)^\[n-gram\]", t)), len(re.findall(r"(?m)^\[TULIP\]", t))
        if (n_ng, n_tl) != (N_PROMPTS, N_PROMPTS):
            E(f"samples.txt should have {N_PROMPTS} n-gram and {N_PROMPTS} TULIP samples, found {n_ng} and {n_tl}. "
              "Re-run a1.py; do not edit samples.txt.")


def load_tok(root, rel, what):
    p = os.path.join(root, *str(rel).split("/"))
    if not os.path.exists(p):
        return None
    try:
        from tokenizers import Tokenizer
    except ImportError:
        W("the 'tokenizers' package is not installed, so tokenizer files were not checked "
          "(pip install -r requirements.txt)."); return None
    try:
        return Tokenizer.from_file(p)
    except Exception as e:
        E(f"{what}: '{rel}' is not a valid tokenizer file ({type(e).__name__}). a1.py saves it; do not edit it.")
        return None


def lossless(tok, what):
    for x in LOSSLESS_PROBES:
        try:
            dec = tok.decode(tok.encode(x, add_special_tokens=False).ids, skip_special_tokens=False)
        except Exception as e:
            E(f"{what}: encoding/decoding failed ({type(e).__name__})."); return
        if dec != x:
            E(f"{what}: tokenizer is not lossless: {x!r} decodes to {dec!r}. Use the kit's train_tokenizer().")
            return


def check_tokenizers(root, m):
    toks = {}
    if m is None:
        return toks
    main = load_tok(root, "tokenizer.json", "main tokenizer")
    if main is not None:
        lossless(main, "tokenizer.json")
        V = main.get_vocab_size()
        if V != MAIN_VOCAB:
            E(f"tokenizer.json has vocab size {V}; A1 uses {MAIN_VOCAB}.")
        if num(m.get("vocab_size")) and V != m["vocab_size"]:
            E(f"meta.vocab_size = {m['vocab_size']} but tokenizer.json has {V}.")
        toks["main"] = main
    sw = m.get("sweep")
    if not isinstance(sw, list) or not sw:
        E("meta.sweep must list the vocab sweep (a1.py fills it in)."); return toks
    seen = set()
    for i, e in enumerate(sw):
        if not isinstance(e, dict):
            E(f"meta.sweep[{i}] must be an object."); continue
        miss = [k for k in ("vocab_size", "tokenizer_file", "ppl_token", "ppl_byte", "n_tokens") if k not in e]
        if miss:
            E(f"meta.sweep[{i}] is missing {miss}."); continue
        if not all(num(e[k]) for k in ("vocab_size", "ppl_token", "ppl_byte", "n_tokens")):
            E(f"meta.sweep[{i}]: vocab_size, ppl_token, ppl_byte and n_tokens must be numbers."); continue
        seen.add(e["vocab_size"])
        if e["ppl_byte"] <= 1 or e["ppl_byte"] >= 256 or e["ppl_token"] <= 1:
            E(f"sweep vocab {e['vocab_size']}: perplexities out of range (per byte must be between 1 and 256).")
        t = load_tok(root, e["tokenizer_file"], f"sweep vocab {e['vocab_size']}")
        if t is not None and t.get_vocab_size() != e["vocab_size"]:
            E(f"meta.sweep[{i}].vocab_size = {e['vocab_size']} but {e['tokenizer_file']} has {t.get_vocab_size()}.")
        if t is not None:
            lossless(t, e["tokenizer_file"])
        identity(e["ppl_token"], e["ppl_byte"], e["n_tokens"], m.get("n_bytes"), f"sweep vocab {e['vocab_size']}")
    if seen and set(SWEEP) - seen:
        E(f"the sweep must contain vocab sizes {list(SWEEP)}; missing {sorted(set(SWEEP) - seen)}. Re-run a1.py.")
    return toks


def check_with_data(m, toks):
    """Recount N_bytes and the 8k n-gram's N_tokens on YOUR held-out set (uses the kit's data; no perplexities)."""
    try:
        sys.path.insert(0, KIT)
        from load_data import load_lm
        _, held = load_lm(m["student_number"])
    except Exception:
        notes.append("data not available here: byte/token recount skipped")
        return
    nb = sum(len(x.encode("utf-8")) for x in held)
    if m.get("n_bytes") != nb:
        E(f"meta.n_bytes = {m.get('n_bytes')} but your 300 held-out paragraphs have {nb} UTF-8 bytes. Re-run a1.py "
          "with the same student number.")
    else:
        notes.append(f"n_bytes {nb} matches your held-out set")
    if "main" in toks:
        n = sum(len(e.ids) for e in toks["main"].encode_batch(held, add_special_tokens=False))
        if m.get("ngram_n_tokens") != n:
            E(f"meta.ngram_n_tokens = {m.get('ngram_n_tokens')} but tokenizer.json gives {n} tokens on your held-out set.")
        else:
            notes.append(f"ngram_n_tokens {n} matches tokenizer.json")


# ------------------------------------------------------------------ findings.md / reflection.md / code
def sections(text, pattern):
    parts = re.split(pattern, text)
    return {parts[i].strip(): parts[i + 1] for i in range(1, len(parts) - 1, 2)}


def answer_words(body):
    """Words of an answer: HTML comments and the quoted question lines (starting with '>') do not count."""
    body = strip_comments(body)
    return " ".join(l for l in body.splitlines() if not l.lstrip().startswith(">")).split()


def check_texts(root):
    fp = os.path.join(root, "findings.md")
    if os.path.exists(fp):
        secs = {k.upper(): v for k, v in sections(read_text(fp), r"(?im)^\s*##\s*(Q[1-9])\b[^\n]*$").items()}
        for q in ("Q1", "Q2"):
            if q not in secs:
                E(f"findings.md: no heading '## {q}'. Keep the two headings of the template exactly.")
                continue
            words = answer_words(secs[q])
            if len(words) < 8:
                E(f"findings.md: {q} is empty or too short. Write your answer below the quoted question (2-4 sentences).")
            elif not re.search(r"\d", " ".join(words)):
                W(f"findings.md: {q} quotes no numbers. Answers are graded on whether they use YOUR numbers.")
    rp = os.path.join(root, "reflection.md")
    if os.path.exists(rp) and not os.path.exists(os.path.join(root, "reflection.pdf")):
        t = read_text(rp)
        m = re.search(r"(?im)^\s*##\s*AI[\s-]*use declaration\s*$", t)
        if not m:
            E("reflection.md: no heading '## AI-use declaration'. Keep it from the template and write your declaration "
              "under it ('No AI tools were used.' is fine).")
        else:
            body = re.split(r"(?m)^\s*#", t[m.end():])[0]
            if len(answer_words(body)) < 3:
                E("reflection.md: the AI-use declaration is empty. Say which parts (if any) used AI tools and how you "
                  "checked them; 'No AI tools were used.' is also fine.")
            # Count only what the student wrote under the three question headings (## 1. / ## 2. / ## 3.);
            # the template's own title, instructions and headings are not part of the answer.
            qs = {k: answer_words(v) for k, v in
                  sections(t[:m.start()], r"(?m)^\s*##\s*([123])\.[^\n]*$").items()}
            missing = [k for k in ("1", "2", "3") if k not in qs]
            if missing:
                W("reflection.md: question heading(s) " + ", ".join("'## " + k + ".'" for k in missing) +
                  " not found. Keep the three headings of the template exactly.")
            thin = [k for k in ("1", "2", "3") if k in qs and len(qs[k]) < 10]
            if thin:
                W("reflection.md: question(s) " + ", ".join(thin) + " are (almost) empty. Each question is graded; "
                  "2-3 sentences per question is enough.")
            total = sum(len(v) for v in qs.values())
            if total > 210:
                W(f"reflection.md: your three answers have about {total} words; the limit is 200 "
                  "(the AI-use declaration does not count).")


# ------------------------------------------------------------------ main
def main(argv):
    try:
        return run(argv)
    finally:
        while TMP:
            shutil.rmtree(TMP.pop(), ignore_errors=True)


def run(argv):
    args = [a for a in argv[1:] if not a.startswith("--")]
    if not args:
        print(__doc__); return 2
    root, zname, names = open_submission(args[0])
    zm = re.fullmatch(r"A1_(\d+)\.zip", zname or "")
    zip_sn = zm.group(1) if zm else None
    if root:
        check_forbidden(names)
        check_required(root)
        d = load_json(root)
        if d is not None:
            check_numbers(d)
            m = check_meta(d, zip_sn)
            check_samples(d, root)
            toks = check_tokenizers(root, m)
            if m and str(m.get("student_number", "")).strip().isdigit():
                check_with_data(m, toks)
        check_texts(root)
    for n in notes:
        print(f"  {OK} {n}")
    for w in warnings:
        print(f"  {WARN} {w}")
    for e in errors:
        print(f"  {ERR} {e}")
    if errors:
        print(f"{ERR} A1: {len(errors)} error(s), {len(warnings)} warning(s). Fix the errors (✗), rebuild the zip and "
              "run the checker again.")
        return 1
    print(f"{OK} A1: format OK ({len(warnings)} warning(s)): ready to upload.")
    return 0


if __name__ == "__main__":
    try:
        rc = main(sys.argv)
    except KeyboardInterrupt:
        rc = 130
    except Exception as e:                      # the checker must never crash on a student
        print(f"{ERR} A1: the checker hit an unexpected problem ({type(e).__name__}). Please post this line on the "
              "course forum; your submission may still be fine.")
        rc = 3
    sys.exit(rc)
