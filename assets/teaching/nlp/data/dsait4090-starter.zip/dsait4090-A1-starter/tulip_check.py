"""Check your TULIP set-up (at most 3 small requests). Run this EARLY, not on the evening of the deadline.

    python tulip_check.py                          # optional: --student-number 1234567

Checks: (1) your key is in .env, (2) TULIP's host resolves and accepts a connection (TU Delft network or
eduVPN), (3) the model 'chat' is listed, (4) a short generation works, (5) input scoring (log-probs of your
text) works. Each failing item says how to fix it. The exit code is 0 when all items pass.
This script always talks to the real TULIP (TULIP_MOCK is ignored) and never uses the cache.
"""
import argparse, os, sys

KIT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, KIT)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--student-number", default=None)
    a = ap.parse_args()
    import tulip_client as tc
    ok_core = True

    def line(ok, what, fix=None):
        print(f"{'✓' if ok else '✗'} {what}")
        if fix and not ok:
            print(f"    fix: {fix}")

    # 1. key
    try:
        key_ok = tc.read_key() is not None
        key_fix = (f"copy .env.example to .env and put your personal key after {tc.KEY_NAME}= "
                   f"(looked in {tc.env_file()}; never share or commit this file).")
    except tc.TulipError as e:
        key_ok, key_fix = False, str(e)
    line(key_ok, f"key: {tc.KEY_NAME} found" if key_ok else f"key: {tc.KEY_NAME} not found", key_fix)
    ok_core &= key_ok

    # 2. network
    resolves, connects, msg = tc.can_connect()
    line(resolves and connects, f"network: {msg}",
         "connect to the TU Delft network or eduVPN (the eduVPN app, TU Delft as institute), then run this again. "
         "TULIP is not reachable from the open internet.")
    ok_core &= resolves and connects
    if not ok_core:
        print("\n✗ Fix the items above first; the remaining checks need them.")
        return 1

    client = tc.TulipClient(student_number=a.student_number, mock=False)
    # 3. model list
    try:
        ids = client.list_models()
        has = tc.MODEL in ids
        line(has, f"models: '{tc.MODEL}' is available" if has else f"models: '{tc.MODEL}' not in {ids}",
             "TULIP's model names have changed: please report this on the course forum.")
        ok_core &= has
    except tc.TulipError as e:
        # Not fatal: TULIP's model list has refused keys (HTTP 401) that work fine for generation and scoring,
        # so the two checks below are the real test of your key.
        print(f"! models: could not list TULIP's models ({e.__class__.__name__}); not needed, continuing")

    # 4. a short generation
    try:
        out = client.generate(["The capital of the Netherlands is"], max_tokens=5, temperature=0.0, use_cache=False)[0]
        line(True, f"generation: works (got {out.strip()[:40]!r})")
    except tc.TulipError as e:
        line(False, "generation: failed", str(e))
        ok_core = False

    # 5. input scoring: one short text, sent as "<bos>" + text; the client checks the protocol
    try:
        sc = client.score(["The capital of France is Paris."], use_cache=False)[0]
        line(True, f"input scoring: works ({len(sc)} tokens scored after <bos>; last token log-prob {sc[-1][1]:.2f})")
    except tc.ScoringNotEnabled as e:
        line(False, "input scoring: not available", str(e))
        ok_core = False
    except tc.TulipError as e:
        line(False, "input scoring: failed", str(e))
        ok_core = False

    print(f"\nTULIP tokens used by this check: {client.tokens_used}. Requests are logged (no text) in tulip_usage.jsonl.")
    print("✓ Core checks pass: you can use TULIP." if ok_core else "✗ Some core checks failed: see the fixes above.")
    return 0 if ok_core else 1


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        sys.exit(130)
