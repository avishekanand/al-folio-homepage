# A1 findings

Answer each question in 2-4 sentences below the quoted question, using the numbers your run printed (they are
also in `submission/a1_results.json`). Lines of arithmetic do not count towards the sentence limit.
Keep the two `## Q` headings exactly as they are.

## Q1
> Rank your 257-vocab n-gram, your 8k n-gram and TULIP by per-token perplexity, then by per-byte perplexity, quoting the numbers. Why do the two rankings disagree, and which one is the fair comparison? Why is the gap between TULIP's per-token and per-byte perplexity so much larger than for your n-gram?


## Q2
> Compare your 8k n-gram and TULIP per byte, quoting both numbers. Is the result what you expected from a bigram model versus a large neural model? Give two plausible reasons, and support each with evidence from your own run — for example the tokens one model finds most surprising (a1.py prints the 10 most surprising tokens of each model), or how the generated text reads.

